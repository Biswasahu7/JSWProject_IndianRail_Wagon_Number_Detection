import pyodbc

try:
    print("Try to connect")
    # log.info("Try to connect mssql server")
    # conn = pyodbc.connect('DRIVER={ODBC Drive  r 17 for SQL Server};Server=DESKTOP-N33MAFB;Database=RMHS_5MT_rakeDetails;UID=sa;PWD=Password@123;MARS_connection=yes')
    #conn = pymssql.connect(server='172.21.25.164', user='sa', password='admin@123', database='cvml')
    # cursor = conn.cursor()
    # cursor.execute('''CREATE TABLE TWarning (CameraName nvarchar(50),WarningName nvarchar(50),Time datetime, CameraIP nvarchar(50), Objectname nvarchar(50) ''')
    # print("Table created")
    # conn.commit()
    # for row in cursor.columns(table='tblWarning'):
    #
    #       print(row.column_name)
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
        'Server=DESKTOP-N33MAFB;'
        'Database=RMHS_5MT_rakeDetails;'
        'UID=sa;'
        'PWD=Password@123;'
        'MARS_connection=yes;')

    cursor = conn.cursor()

    print("Connection successfull")
    cursor.close()
    conn.close()
    # log.info("mssql server connection successful")

except Exception as e:
    print("connect failed", e)
    # log.error("mssql server connection failed {}".format(e))