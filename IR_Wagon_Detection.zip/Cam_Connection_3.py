# **************************
# Camera Connection
# **************************

# Cam 1 IP = 192.168.2.241
# Cam 2 IP = 192.168.2.242
# Cam 3 IP = 192.168.2.243
# User Name - admin
# Password - Password@123

# Importing required libraries
import datetime
import cv2 as cv2
import logging
from logging.handlers import TimedRotatingFileHandler
import time
import numpy as np

# VARIABLES
sec=0.0
framerate=1.0
out=None
t1=time.time()

# Assigning IP address
ip = "192.168.2.241"
ip1 = "192.168.2.242"
ip2 = "192.168.2.243"

# Using opencv for capturing image
cap = cv2.VideoCapture()

# Camera connection using credentials
cap.open("rtsp://admin:Password@123@{}/Streaming/channels/1/?tcp".format(ip2))

# LOGGER
l1 = datetime.datetime.now()
logger = logging.getLogger("Rotating Log")
logger.setLevel(logging.INFO)
handler = TimedRotatingFileHandler("/home/jsw/PycharmProjects/pythonProject/log_cam_connection_3/log_{}.log".format(l1), when="m", interval=60)
logger.addHandler(handler)

while True:
    try:
        # GET CURRENT TIME/SEC
        t2=time.time()
        if t2-t1>3540:
            logger.info("Its 1 hr...will create new video")
            t1=time.time()
            out=None

        # Reading Image from live camera
        _, img=cap.read()

        # Checking Image from live camera
        if img is None:
            print("Blank Image")
            logger.info("None image-{}".format(datetime.datetime.now()))
            continue

        # SKIP FRAMES
        sec = sec + framerate
        if sec % 2 != 0:
            continue

        # RESIZING FRAME
        scale_percent = 40
        width = int(img.shape[1] * scale_percent / 100)
        height = int(img.shape[0] * scale_percent / 100)
        img = cv2.resize(img, (width, height), interpolation=cv2.INTER_AREA)
        height, width, _ = img.shape
        size = (width, height)

        # DEFINE VIDEO WRITER
        if out == None:
            logger.info("Creating VideoWriter")
            # out = cv2.VideoWriter("/media/jsw/Data/saved_video_2/video_{}.avi".format(datetime.datetime.now()),cv2.VideoWriter_fourcc(*'DIVX'), 10, size)
            out = cv2.VideoWriter("/home/jsw/Desktop/Cam _3_Video/video_{}.avi".format(datetime.datetime.now()),cv2.VideoWriter_fourcc(*'DIVX'), 10, size)
            logger.info("VideoWriter Created")

        # SAVING VIDEO
        out.write(img)
        print("Cam2_alive-{}".format(datetime.datetime.now()))
        # if t2-t1%10==0:
        logger.info("alive-{}".format(datetime.datetime.now()))


        # Camera live image show
        # cv2.imshow('Live Camera image', img)
        # cv2.waitKey(1)

    except Exception as e:
        print("Theres an exception-{}".format(e))